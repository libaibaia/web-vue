/**
 * frontend common language package
 */
export default {
    Integral: 'Integral',
    Balance: 'Balance',
    Language: 'Language',
    Copyright: 'Copyright',
    'Member Center': 'Member Center',
    'Logout login': 'Logout',
    'Member center disabled': 'The member center has been disabled. Please contact the webmaster to turn it on.',
}
