export default {
    'Account information': 'Account information',
    'personal data': 'personal data',
    'Filled in': 'Filled in',
    'Not filled in': 'Not filled in',
    mobile: 'mobile',
    email: 'email',
    'Last login IP': 'Last login IP',
    'Last login': 'Last login',
    'Growth statistics': 'Growth statistics',
}
