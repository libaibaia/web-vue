export default {
    GroupName: '组名',
    'Group name': '组别名称',
    jurisdiction: '权限',
    'Parent group': '上级分组',
    'The parent group cannot be the group itself': '上级分组不能是分组本身',
}
