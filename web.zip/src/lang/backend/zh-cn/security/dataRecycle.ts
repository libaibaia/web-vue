export default {
    'Rule name': '规则名称',
    controller: '控制器',
    'data sheet': '数据表',
    'Data table primary key': '数据表主键',
    'Deleting monitoring': '删除监控中',
    'The rule name helps to identify deleted data later': '规则名称有助于后续识别被删数据',
    'The data collection mechanism will monitor delete operations under this controller': '数据回收机制将监控此控制器下的删除操作',
    'Corresponding data sheet': '对应数据表',
}
