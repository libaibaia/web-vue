export default {
    'Rule name': '规则名称',
    controller: '控制器',
    'data sheet': '数据表',
    'Data table primary key': '数据表主键',
    'Sensitive fields': '敏感字段',
    'Modifying monitoring': '修改监控中',
    'The rule name helps to identify the modified data later': '规则名称有助于后续识别被修改数据',
    'The data listening mechanism will monitor the modification operations under this controller': '数据监听机制将监控此控制器下的修改操作',
    'Corresponding data sheet': '对应数据表',
    'Filling in field notes helps you quickly identify fields later': '填写字段注释有助于后续快速识别字段',
}
