export default {
    'Normal routing': 'Normal routing',
    'Member center menu contents': 'Member center menu directory ',
    'Member center menu items': 'Member Center menu items',
    'English name': 'English name',
    'Web side routing path': 'Web side routing path',
    'For example, if you add account/overview as a route only':
        'Please start with /src for web side component paths, such as: /src/views/frontend/index.vue',
    'Web side component path, please start with /src, such as: /src/views/frontend/index':
        "For example, if you add 'account/overview' as a route only, then you can additionally add 'account/overview', 'account/overview/:a' and 'account/overview/:b/:C' as menus only.",
}
