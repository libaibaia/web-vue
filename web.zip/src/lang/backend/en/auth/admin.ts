export default {
    username: 'Username',
    nike: 'nike',
    grouping: 'Grouping',
    'head portrait': 'Profile picture',
    mailbox: 'Mailbox',
    mobile: 'Mobile Number',
    'Last login': 'Last login',
    Password: 'Password',
    'Please leave blank if not modified': 'Please leave blank if you do not modify.',
    'Personal signature': 'Personal Signature',
    'Administrator login': 'Administrator Login Name',
}
