export default {
    GroupName: 'Group Name',
    'Group name': 'Group Name',
    jurisdiction: 'Permissions',
    'Parent group': 'Superior group',
    'The parent group cannot be the group itself': 'The parent group cannot be the group itself',
}
