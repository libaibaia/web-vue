export default {
    admin_id: 'Manage ID',
    username: 'Manage Username',
    title: 'Title',
    data: 'Request Data',
    url: 'URL',
    ip: 'IP',
    useragent: 'UserAgent',
    createtime: 'Creation Time',
    'Operation administrator': 'Operation administrator',
    'Operator IP': 'Operator IP',
    'Request data': 'Request Data',
}
