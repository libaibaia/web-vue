export default {
    id: 'id',
    table_name: 'table_name',
    table: 'table',
    fields: 'fields',
    status: 'status',
    'status delete': 'status delete',
    'status success': 'status success',
    'status error': 'status error',
    'status start': 'status start',
    create_time: 'create_time',
    'quick Search Fields': 'id,table_name',
}
