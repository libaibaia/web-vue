export default {
    'Rule name': 'Rule name',
    controller: 'Controller',
    'data sheet': 'Data table',
    'Data table primary key': 'Data table primary key',
    'Sensitive fields': 'Sensitive fields',
    'Modifying monitoring': 'Modify monitoring',
    'The rule name helps to identify the modified data later': 'Rule names help to identify modified data subsequently later.',
    'The data listening mechanism will monitor the modification operations under this controller':
        'The data monitor mechanism will monitor the modified operation under this controller.',
    'Corresponding data sheet': 'Corresponding data table',
    'Filling in field notes helps you quickly identify fields later': 'Fill in field comments help to identify fields quickly later.',
}
