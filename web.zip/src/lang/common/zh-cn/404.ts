export default {
    'problems tip': '你的网页遇到了一些问题，系统正在优化和上报故障信息，我们在未来将改善和减少这种情况的发生.',
    'We will automatically return to the previous page when we are finished': '我们将在完成后自动返回到上一页。',
    'Return to home page': '返回首页',
    'Back to previous page': '返回上一页',
}
