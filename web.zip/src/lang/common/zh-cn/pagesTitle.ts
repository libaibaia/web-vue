export default {
    home: '首页',
    admin: '后台',
    adminLogin: '登录',
    notFound: '页面找不到了',
    noPower: '无访问权限',
    noTitle: '无标题',
    Loading: 'Loading...',
    User: '会员中心',
    userLogin: '会员登录',
}
