import pkg from '../../package.json'
export const run = () => {
    console.log(`✨ ${pkg.name} - build successfully!`)
}
run()
